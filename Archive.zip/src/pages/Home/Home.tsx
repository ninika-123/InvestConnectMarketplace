const Home = () => {
  return <main></main>;
};

export default Home;
