export const menu: {
  id: string;
  name: string;
  path: string;
}[] = [
  {
    id: "1",
    name: "Home",
    path: "/",
  },
  {
    id: "2",
    name: "Investor",
    path: "/investor",
  },
  {
    id: "3",
    name: "Owners",
    path: "/owners",
  },
  {
    id: "4",
    name: "services Providers",
    path: "/services",
  },
  {
    id: "6",
    name: "price",
    path: "/price",
  },
  {
    id: "5",
    name: "Blog",
    path: "/blog",
  },
  {
    id: "6",
    name: "Contact",
    path: "/contact",
  },
];
